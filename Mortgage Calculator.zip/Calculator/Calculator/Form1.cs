﻿//Zalim Tkhagazitov
//CIS 411
//Mortgage Calculator
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Loan;

namespace Calculator
{
    public partial class Form1 : Form
    {
        Calculations zalikNomerOdin = new Calculations();
        DataTable table = new DataTable();

        public Form1()
        {
            InitializeComponent();

            InitDefaultValues();
        }

        private void InitDefaultValues()
        {
            principalTextBox.Text = zalikNomerOdin.Principal.ToString();
            interestTextBox.Text = zalikNomerOdin.InterestRate.ToString();
            monthTextBox.Text = zalikNomerOdin.Months.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            table.Columns.Add("Ending Balance", typeof(decimal));
            table.Columns.Add("Beginning Balance", typeof(decimal));
            table.Columns.Add("Interest Paid", typeof(decimal));
            table.Columns.Add("Principal Paid", typeof(decimal));

            dataGridView1.DataSource = table;

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            var principal = decimal.Parse(principalTextBox.Text);
            var interestRate = decimal.Parse(interestTextBox.Text);
            var months = int.Parse(monthTextBox.Text);

            zalikNomerOdin.SetCalculationData(principal, interestRate, months);
            outputTextBox.Text = zalikNomerOdin.CalculateMonthlyPayment().ToString();


            var amortizationCalculations = zalikNomerOdin.CalculateAmortization();


            amortizationCalculations.ForEach(record =>
            {
                DataRow dr = table.NewRow();
                dr["Ending Balance"] = record.TheEndingBalance;
                dr["Beginning Balance"] = record.TheBeginingBalance;
                dr["Interest Paid"] = record.TheInteresetPaid;
                dr["Principal Paid"] = record.ThePrincipalPaid;
                table.Rows.Add(dr);
            });

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
