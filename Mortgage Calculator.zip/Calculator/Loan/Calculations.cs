﻿//Zalim Tkhagazitov
//CIS 411
//Mortgage Calculator
using System;
using System.Collections.Generic;
using System.Text;

namespace Loan
{
    public class Calculations
    {
        public decimal Principal { get; set; } = 100000;
        public decimal InterestRate { get; set; } = 0.06M;
        public int Months { get; set; } = 120;

        public void SetCalculationData(decimal principal, decimal interestRate, int months)
        {
            Principal = principal;
            InterestRate = interestRate;
            Months = months;

        }
        public decimal CalculateMonthlyPayment()
        {

            double monthlyInterestRate = (double) InterestRate / 12;

            var monthlyPayment = (monthlyInterestRate + (monthlyInterestRate / (Math.Pow(1 + monthlyInterestRate, Months) - 1)) ) * (double)Principal;

            return Math.Round((decimal) monthlyPayment, MidpointRounding.AwayFromZero);

        }

        public List<AmortizationLine> CalculateAmortization()
        {

            var monthlyPayment = (double) CalculateMonthlyPayment();

            double monthlyInterestRate = (double)InterestRate / 12;
            
            var beginningBalance = (double) Principal;
            var endingBalance = (double) Principal;


            List<AmortizationLine> result = new List<AmortizationLine>();

            result.Add(new AmortizationLine(endingBalance, beginningBalance, 0, 0));

            for (int month = 0; month < Months; month++)
            { 
                double interestPaid = endingBalance * monthlyInterestRate;
                double principalPaid = monthlyPayment - interestPaid;

                beginningBalance = endingBalance;
                endingBalance -= monthlyPayment;

                result.Add(new AmortizationLine(endingBalance, beginningBalance, interestPaid, principalPaid));
            }

            return result;
        }
    }


    public class AmortizationLine
    {
        public decimal TheEndingBalance { get; set; } = 0;
        public decimal TheBeginingBalance { get; set; } = 0;
        public decimal TheInteresetPaid { get; set; } = 0;
        public decimal ThePrincipalPaid { get; set; } = 0;
        
        public AmortizationLine(double endingBalance, double beginingBalance, double interestPaid, double principalPaid)
        {
            TheEndingBalance = (decimal) endingBalance;
            TheBeginingBalance = (decimal) beginingBalance;
            TheInteresetPaid = (decimal) interestPaid;
            ThePrincipalPaid = (decimal) principalPaid;
        }

    }
    
  
}
